const { Kafka } = require('kafkajs');
var xmlparser = require('xml2json');
const fs= require('fs');
const { promisify }= require('util');

const kafka = new Kafka({
  clientId: 'my-app',
  brokers: ['localhost:9092']
})


const producer = kafka.producer();
//promisifying the read file
const readFileAsync= promisify(fs.readFile);
const consumer = kafka.consumer({ groupId: 'test-group' })

//this function reads xml from thre supplied file 
async function readXmlFile(file_name){
  const xmlrec =await readFileAsync(file_name);
  return xmlrec.toString();

}
const run = async () => {
  // Producing
  await producer.connect();
  
  var inputRecords=xmlparser.toJson(await readXmlFile('test.xml'))
  await producer.send({
    topic: 'test-topic',
    messages: [
      { value: inputRecords},
    ],
  })

}

run().catch(console.error)